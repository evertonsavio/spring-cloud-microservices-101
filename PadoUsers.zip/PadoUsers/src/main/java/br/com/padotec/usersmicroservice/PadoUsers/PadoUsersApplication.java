package br.com.padotec.usersmicroservice.PadoUsers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PadoUsersApplication {

	public static void main(String[] args) {
		SpringApplication.run(PadoUsersApplication.class, args);
	}

}
